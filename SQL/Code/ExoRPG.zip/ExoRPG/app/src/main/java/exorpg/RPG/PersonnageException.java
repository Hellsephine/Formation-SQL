package exorpg.RPG;

public class PersonnageException extends NullPointerException{
    PersonnageException(String message){
        super(message);
    }
}
