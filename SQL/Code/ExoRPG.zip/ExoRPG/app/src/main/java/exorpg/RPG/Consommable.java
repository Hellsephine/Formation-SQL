package exorpg.RPG;

public interface Consommable {
    public void consommer(Personnage cible);

}
